"""检查服务器状态"""
import paramiko

SERVER = "120.77.171.21"
USERNAME = "root"
PASSWORD = "!1iIlL.,44166"
PROJECT_DIR = "/opt/sageai"

def ssh_exec(cmd):
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(SERVER, username=USERNAME, password=PASSWORD, timeout=30)
    try:
        stdin, stdout, stderr = ssh.exec_command(cmd)
        stdout.channel.recv_exit_status()
        return stdout.read().decode('utf-8'), stderr.read().decode('utf-8')
    finally:
        ssh.close()

def main():
    print("=" * 60)
    print("检查服务器状态")
    print("=" * 60)
    
    try:
        # 检查容器
        print("\n[1/5] 容器状态...")
        output, error = ssh_exec("docker ps -a")
        print(output)
        
        # 检查项目目录
        print("\n[2/5] 项目目录结构...")
        output, error = ssh_exec(f"ls -la {PROJECT_DIR}")
        print(output)
        
        # 检查 docker-compose.yml
        print("\n[3/5] Docker Compose 配置...")
        output, error = ssh_exec(f"cat {PROJECT_DIR}/docker-compose.yml")
        print(output)
        
        # 检查后端目录
        print("\n[4/5] 后端文件...")
        output, error = ssh_exec(f"ls -la {PROJECT_DIR}/backend/")
        print(output)
        
        # 检查容器日志
        print("\n[5/5] sageai 容器日志...")
        output, error = ssh_exec("docker logs sageai 2>&1 | tail -50")
        print(output)
        
    except Exception as e:
        print(f"\n[ERROR]: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()