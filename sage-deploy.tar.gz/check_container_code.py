"""检查容器内的实际代码"""
import paramiko

SERVER = "120.77.171.21"
USERNAME = "root"
PASSWORD = "!1iIlL.,44166"

def ssh_exec(cmd):
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(SERVER, username=USERNAME, password=PASSWORD, timeout=30)
    try:
        stdin, stdout, stderr = ssh.exec_command(cmd)
        stdout.channel.recv_exit_status()
        return stdout.read().decode('utf-8'), stderr.read().decode('utf-8')
    finally:
        ssh.close()

def main():
    print("=" * 60)
    print("检查容器内的实际代码")
    print("=" * 60)
    
    try:
        # 查找包含 handleInvite 的文件
        print("\n[1/3] 查找 handleInvite...")
        cmd = "docker exec sageai grep -r 'handleInvite' /app/"
        output, error = ssh_exec(cmd)
        print(output if output else "未找到")
        
        # 检查 CreditSupplyModal 组件
        print("\n[2/3] 检查 CreditSupplyModal...")
        cmd = "docker exec sageai grep -A 20 'handleInvite' /app/frontend/static/*.js 2>/dev/null | head -n 30"
        output, error = ssh_exec(cmd)
        print(output if output else "未找到")
        
        # 检查完整的 handleInvite 函数
        print("\n[3/3] 检查 handleInvite 函数实现...")
        cmd = """docker exec sageai grep -o 'const handleInvite.*console.error.*' /app/frontend/static/*.js 2>/dev/null || echo '未找到'"""
        output, error = ssh_exec(cmd)
        print(output if output else "未找到")
        
    except Exception as e:
        print(f"\n[ERROR]: {str(e)}")

if __name__ == "__main__":
    main()