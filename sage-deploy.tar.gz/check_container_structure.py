"""检查容器内的文件结构"""
import paramiko

SERVER = "120.77.171.21"
USERNAME = "root"
PASSWORD = "!1iIlL.,44166"

def ssh_exec(cmd):
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(SERVER, username=USERNAME, password=PASSWORD, timeout=30)
    try:
        stdin, stdout, stderr = ssh.exec_command(cmd)
        stdout.channel.recv_exit_status()
        return stdout.read().decode('utf-8'), stderr.read().decode('utf-8')
    finally:
        ssh.close()

def main():
    print("=" * 60)
    print("检查容器内的文件结构")
    print("=" * 60)
    
    try:
        # 列出容器内的所有文件
        print("\n[1/4] 列出容器内的所有文件...")
        output, error = ssh_exec("docker exec sageai find /app/frontend -type f 2>/dev/null | head -n 30")
        print(output)
        
        # 列出static目录
        print("\n[2/4] 列出static目录...")
        output, error = ssh_exec("docker exec sageai ls -la /app/frontend/static/ 2>/dev/null | head -n 20")
        print(output)
        
        # 检查Home文件
        print("\n[3/4] 检查Home文件...")
        output, error = ssh_exec("docker exec sageai ls /app/frontend/static/Home*.js 2>/dev/null")
        print(output)
        
        # 检查Home文件内容
        print("\n[4/4] 检查Home文件内容...")
        output, error = ssh_exec("docker exec sageai cat /app/frontend/static/Home*.js 2>/dev/null | head -n 1 | cut -c1-200")
        print(output[:200] if output else "文件不存在")
        
    except Exception as e:
        print(f"\n[ERROR]: {str(e)}")

if __name__ == "__main__":
    main()