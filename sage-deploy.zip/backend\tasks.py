"""任务队列管理模块"""
import uuid
import asyncio
import logging
import contextvars
from typing import Dict, Optional, List
from dataclasses import dataclass
from enum import Enum

logger = logging.getLogger(__name__)

# 全局trace_id上下文变量
task_trace_id_context = contextvars.ContextVar('task_trace_id', default='unknown')

class TaskStatus(Enum):
    PENDING = "pending"
    UPLOADING = "uploading"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"

@dataclass
class Task:
    task_id: str
    filename: str
    file_size: int
    status: TaskStatus
    user_id: Optional[int] = None  # 添加用户ID字段
    remaining_bonus: Optional[int] = None  # 剩余额度（用于实时更新）
    record_id: Optional[int] = None  # 报告记录ID
    progress: int = 0
    result: Optional[str] = None
    error: Optional[str] = None
    metadata: Optional[Dict] = None
    validation: Optional[Dict] = None
    summary: Optional[Dict] = None
    trace_id: Optional[str] = None  # 链路追踪ID

# 任务存储（内存，实际生产环境应使用Redis等持久化存储）
_tasks: Dict[str, Task] = {}
concurrent_semaphore = asyncio.Semaphore(3)  # 并发控制，同时处理不超过3个任务

def create_task(filename: str, file_size: int, user_id: Optional[int] = None) -> Task:
    """创建新任务"""
    task_id = str(uuid.uuid4())
    # 获取当前请求的trace_id
    try:
        from security.logging_utils import trace_id_context
        current_trace_id = trace_id_context.get()
    except:
        current_trace_id = 'unknown'
    
    task = Task(
        task_id=task_id,
        filename=filename,
        file_size=file_size,
        user_id=user_id,
        status=TaskStatus.PENDING,
        progress=0,
        trace_id=current_trace_id
    )
    _tasks[task_id] = task
    return task

def get_task(task_id: str) -> Optional[Task]:
    """获取任务"""
    return _tasks.get(task_id)

def update_task(task_id: str, **kwargs):
    """更新任务状态"""
    task = _tasks.get(task_id)
    if task:
        for key, value in kwargs.items():
            if hasattr(task, key):
                setattr(task, key, value)

def delete_task(task_id: str):
    """删除任务"""
    if task_id in _tasks:
        del _tasks[task_id]

def get_all_tasks() -> List[Task]:
    """获取所有任务"""
    return list(_tasks.values())

async def run_with_concurrent_limit(coroutine):
    """带并发限制的任务执行"""
    async with concurrent_semaphore:
        try:
            return await coroutine
        except Exception as e:
            logger.error(f"任务执行失败: {e}")
            raise