#!/bin/bash
# ============================================================
# SageAI 一键部署脚本
# 用法: bash deploy.sh [--docker]
# ============================================================
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

echo "============================================="
echo "  SageAI 部署脚本"
echo "  $(date '+%Y-%m-%d %H:%M:%S')"
echo "============================================="

USE_DOCKER=false
if [ "$1" = "--docker" ]; then
    USE_DOCKER=true
fi

if [ "$USE_DOCKER" = true ]; then
    # ============================================================
    # Docker 部署模式
    # ============================================================
    echo ""
    echo "[1/4] 拉取最新代码..."
    git pull origin main

    echo ""
    echo "[2/4] 检查环境变量..."
    if [ ! -f ".env.production" ]; then
        echo "  [ERROR] .env.production 文件不存在！"
        echo "  请从 .env.production.example 复制并填写正确配置"
        exit 1
    fi
    echo "  [OK] .env.production 已存在"

    echo ""
    echo "[3/4] 构建 Docker 镜像..."
    docker compose build --no-cache

    echo ""
    echo "[4/4] 启动服务..."
    docker compose down
    docker compose up -d

    echo ""
    echo "============================================="
    echo "  部署完成！"
    echo "  前端: http://localhost"
    echo "  API:  http://localhost:8000"
    echo "  健康检查: http://localhost:8000/health"
    echo ""
    echo "  常用命令:"
    echo "    查看日志: docker compose logs -f"
    echo "    停止服务: docker compose down"
    echo "    重启服务: docker compose restart"
    echo "============================================="

else
    # ============================================================
    # 传统部署模式
    # ============================================================
    echo ""
    echo "[1/5] 拉取最新代码..."
    git pull origin main

    echo ""
    echo "[2/5] 构建前端..."
    cd frontend
    npm ci --production=false
    npm run build
    cd ..

    echo ""
    echo "[3/5] 安装后端依赖..."
    cd backend
    pip install -r requirements.txt
    cd ..

    echo ""
    echo "[4/5] 执行数据库迁移..."
    cd backend
    python migrate_db.py
    cd ..

    echo ""
    echo "[5/5] 重启后端服务..."
    # 如果使用 systemd
    if systemctl is-active --quiet sageai 2>/dev/null; then
        sudo systemctl restart sageai
        echo "  [OK] sageai 服务已重启"
    else
        echo "  [WARN] sageai systemd 服务未找到，请手动启动"
        echo "  启动命令: cd backend && gunicorn main:app -w 4 -k uvicorn.workers.UvicornWorker -b 0.0.0.0:8000"
    fi

    echo ""
    echo "============================================="
    echo "  部署完成！"
    echo "  API: http://localhost:8000"
    echo "  健康检查: http://localhost:8000/health"
    echo "============================================="
fi
